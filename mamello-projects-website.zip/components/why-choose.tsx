import {
  MessageCircle,
  Wallet,
  Home,
  Sparkles,
  ClipboardList,
  Clock,
} from "lucide-react"

const WHY_CHOOSE = [
  {
    icon: MessageCircle,
    title: "Fast WhatsApp Response",
    text: "Send a message and get a reply quickly — no waiting around for days.",
  },
  {
    icon: Wallet,
    title: "Affordable Local Service",
    text: "Fair pricing from a local team. No call-out fees from far away.",
  },
  {
    icon: Home,
    title: "Homes & Businesses",
    text: "We work for private homeowners, landlords, shops, and small businesses.",
  },
  {
    icon: Sparkles,
    title: "Clean Workmanship",
    text: "Tidy sites, neat finishes, and rubble cleared when the job is done.",
  },
  {
    icon: ClipboardList,
    title: "On-Site Quotations",
    text: "We come to you, assess the work, and give you a clear written quote.",
  },
  {
    icon: Clock,
    title: "Reliable Turnaround",
    text: "We show up when we say we will and finish the job properly.",
  },
]

export function WhyChoose() {
  return (
    <section id="why-us" className="py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">
            Why Mamello
          </p>
          <h2 className="mt-2 text-balance font-heading text-3xl font-extrabold tracking-tight text-foreground sm:text-4xl">
            Straight talk. Solid work. No surprises.
          </h2>
          <p className="mt-3 text-pretty text-muted-foreground">
            We&apos;ve built our reputation one neat, on-time job at a time.
            Here&apos;s why locals keep calling us back.
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {WHY_CHOOSE.map((item) => (
            <div
              key={item.title}
              className="rounded-2xl border border-border bg-card p-6 shadow-sm transition-shadow hover:shadow-md"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <item.icon size={22} />
              </div>
              <h3 className="mt-4 font-heading text-lg font-bold text-foreground">
                {item.title}
              </h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                {item.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
